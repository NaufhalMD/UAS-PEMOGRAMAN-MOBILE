package com.naufhal.profesi;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProfesiAdapter extends RecyclerView.Adapter<ProfesiAdapter.ViewHolder> {
    private ArrayList<Profesi> profesis;
    private Context context;

    public ProfesiAdapter(ArrayList<Profesi> profesis, Context context) {
        this.profesis = profesis;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_profesi, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Profesi profesi = profesis.get(position);
        holder.tvName.setText(profesi.getName());
        holder.tvInfo.setText(profesi.getInfo());
        holder.ivLogo.setImageResource(profesi.getLogo());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("ITEM_NAME", profesi.getName());
            intent.putExtra("ITEM_LOGO", profesi.getLogo());
            intent.putExtra("ITEM_DESCRIPTION", profesi.getInfo());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return profesis.size();
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvInfo;
        ImageView ivLogo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_name); // Ganti dengan ID yang sesuai
            tvInfo = itemView.findViewById(R.id.tv_info); // Ganti dengan ID yang sesuai
            ivLogo = itemView.findViewById(R.id.iv_logo); // Ganti dengan ID yang sesuai
        }
    }

    public static abstract class OnItemClickCallback {
        public abstract void onItemClick(Profesi tas, int position);
    }
}