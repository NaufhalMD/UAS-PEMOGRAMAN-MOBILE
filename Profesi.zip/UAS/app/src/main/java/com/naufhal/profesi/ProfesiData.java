package com.naufhal.profesi;

import java.util.ArrayList;

public class ProfesiData {
    private static String[] names = {
            "Progammer",
            "Guru atau Dosen",
            "Tentara",
            "Pilot",
            "Pramugari",
            "Dokter",
            "Nelayan",
            "Pengacara",
            "Petani",
            "Pedagang"
    };
    private static String[] infos = {
            "Programmer adalah orang yang memiliki keahlian khusus dalam merancang suatu program baik aplikasi maupun mengembangkan sebuah situs. Mereka akan menggunakan bahasa pemrograman misalnya Java, C++, python dan lain-lain.",
            "Guru dan dosen adalah orang yang mengajarkan pengetahuan, memberikan bimbingan dan juga evaluasi terhadap ilmu yang diberikannya kepada murid-murid atau peserta didiknya.",
            "Tentara adalah warga yang dilatih dan dipersenjatai untuk bertugas dalam mempertahankan negara guna menghadapi ancaman bersenjata atau militer. Tentara biasanya dibagi menjadi tiga gugus yaitu Tentara Angkatan Darat, Tentara Angkatan laut, dan Tentara Angkatan Udara.",
            "Orang yang menerbangkan pesawat adalah pilot. Pilot biasanya menerbangkan pesawat dengan rekannya yang disebut co-pilot. Seorang pilot memiliki tuntutan yaitu ahli dalam mengemudikan pesawat.",
            "Pramugari adalah seorang staf dari angkutan umum baik di darat, laut dan udara. Para pramugari bertugas untuk melayani penumpang sehingga para penumpang bisa merasa aman dan nyaman selama perjalanan.",
            "Dokter adalah tenaga ahli di bidang kesehatan. Dokter merupakan seseorang atau titik kontak pertama dengan pasien untuk menyelesaikan permasalahan kesehatan dan penyakit yang diderita oleh pasien.",
            "Nelayan adalah sebuah profesi di mana orang yang sehari-harinya bekerja untuk menangkap ikan baik secara tradisional maupun modern. Para nelayan biasanya beraktivitas di laut maupun daerah perairan.",
            "Pengacara adalah bidang pekerjaan di mana seseorang akan memberikan pelayanan dan jasa hukum. Biasanya pengacara akan memberikan nasehat dan membela kliennya dari perkara hukum.",
            "Petani adalah orang yang mengolah tanah sehingga bisa menumbuhkan hasil panen yang biasanya dijual kepada masyarakat sehingga mereka juga bisa memenuhi kebutuhan hidup mereka. Para petani juga bertugas untuk memanen hasil tanaman mereka dan menentukan harga jual di pasaran.",
            "Pedagang adalah orang yang berjualan suatu produk. Produk tersebut bisa saja dihasilkan oleh sendiri ataupun hasil dari orang lain. Mereka bertugas untuk memastikan barang dagangan yang dijual dalam kondisi baik dan mempromosikan atau menawarkan barang dagangan mereka."
    };
    private static int[] logos = {
            R.drawable.progammer,
            R.drawable.guru,
            R.drawable.tentara,
            R.drawable.pilot,
            R.drawable.pramugari,
            R.drawable.dokter,
            R.drawable.nelayan,
            R.drawable.pengacara,
            R.drawable.petani,
            R.drawable.pedagang
    };
    public static ArrayList<Profesi> getDatas() {
        ArrayList<Profesi> profesis = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            Profesi profesi = new Profesi(names[i], infos[i], logos[i]);
            profesis.add(profesi);
        }
        return profesis;
    }
}
