package com.naufhal.profesi;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;


public class Profesi implements Parcelable{
    private String name;
    private String info;
    private int logo;

    public Profesi(String name, String info, int logo) {
        this.name = name;
        this.info = info;
        this.logo = logo;
    }

    protected Profesi(Parcel in) {
        name = in.readString();
        info = in.readString();
        logo = in.readInt();
    }

    public static final Creator<Profesi> CREATOR = new Creator<Profesi>() {
        @Override
        public Profesi createFromParcel(Parcel in) {
            return new Profesi(in);
        }

        @Override
        public Profesi[] newArray(int size) {
            return new Profesi[size];
        }
    };

    public String getName() {
        return name;
    }

    public String getInfo() {
        return info;
    }

    public int getLogo() {
        return logo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(info);
        parcel.writeInt(logo);
    }
}
