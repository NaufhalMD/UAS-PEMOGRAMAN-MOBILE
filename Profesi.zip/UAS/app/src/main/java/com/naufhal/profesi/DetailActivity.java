package com.naufhal.profesi;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        String itemName = getIntent().getStringExtra("ITEM_NAME");
        int itemLogo = getIntent().getIntExtra("ITEM_LOGO", 0);

        String itemDescription = getIntent().getStringExtra("ITEM_DESCRIPTION");

        ImageView imageViewLogo = findViewById(R.id.imageView);
        TextView textViewDetailName = findViewById(R.id.tv_detail_name);
        TextView textViewDetailDescription = findViewById(R.id.tv_detail_base);
        Button buttonKembali = findViewById(R.id.button2);

        imageViewLogo.setImageResource(itemLogo);
        textViewDetailName.setText(itemName);
        textViewDetailDescription.setText(itemDescription);

        buttonKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}